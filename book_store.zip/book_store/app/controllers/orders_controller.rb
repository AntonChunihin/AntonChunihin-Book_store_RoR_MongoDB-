class OrdersController < ApplicationController
  before_action :set_order, only: %i[ show edit update destroy ]
  before_action :authenticate_user!

  # GET /orders or /orders.json
  def index
    @orders = Order.all
  end

  # GET /orders/1 or /orders/1.json
  def show
  end

  # GET /orders/new
  def new
    @order = Order.new
  end

  # GET /orders/1/edit
  def edit
  end

  # POST /orders or /orders.json
  def create
    @order = Order.new(order_params)

    respond_to do |format|
      if @order.save
        format.html { redirect_to order_url(@order), notice: "Order was successfully created." }
        format.json { render :show, status: :created, location: @order }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @order.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /orders/1 or /orders/1.json
  def update
    respond_to do |format|
      if @order.update(order_params)
        format.html { redirect_to order_url(@order), notice: "Заказ был успешно изменен" }
        format.json { render :show, status: :ok, location: @order }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @order.errors, status: :unprocessable_entity }
      end
    end
  end

  def add_book_to_cart
    @cart = current_user.orders.find_by(status: 'cart')
    @cart = current_user.orders.create!(status: 'cart') unless @cart.present?
    book = Book.find_by(id: params[:book_id])

    @cart.books << book
    @cart.update!(items_quantities: { "#{book.id}": 1 })
    redirect_to cart_path
  end

  def checkout_cart
    @cart = current_user.orders.find_by(status: 'cart')
    @cart.update!(delivery_address: params[:delivery_address], payment_kind: params[:payment_kind], delivery_date: params[:delivery_date], status: 'checkout')

    redirect_to order_path(@cart.id)
  end

  def update_item_quantity_in_cart
    cart = current_user.orders.find_by(status: 'cart')
    hash = cart.items_quantities
    case params[:operation]
    when 'add'
      hash[params[:book_id]] += 1
      cart.update(items_quantities: hash)
    when 'remove'
      return if cart.items_quantities[params[:book_id]] == 1

      hash[params[:book_id]] -= 1
      cart.update(items_quantities: hash)
    end
    cart.recalculate!

    redirect_to cart_path
  end

  def add_book_to_order
    order = Order.find(params[:order_id])
    book = Book.find(params[:book_id])
    order.books << book

    redirect_to edit_order_path(order), notice: "Книга: \"#{book.title}\" была добавлена в заказ"
  end

  def remove_book_from_order
    order = Order.find(params[:order_id])
    book = Book.find(params[:book_id])
    order.books.delete(book)
    order.recalculate!

    redirect_to edit_order_path(order), notice: "Книга: \"#{book.title}\" была удалена из заказа"
  end

  def remove_book_from_cart
    @cart = current_user.orders.find_by(status: 'cart')

    book = Book.find(params[:book_id])
    @cart.books.delete(book)
    @cart.recalculate!
    redirect_to cart_path
  end


  private
    # Use callbacks to share common setup or constraints between actions.
    def set_order
      @order = Order.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def order_params
      params.require(:order).permit(:number_of_positions, :delivery_address, :delivery_date, :payment_kind, :status, :total_cost, :user_id)
    end
end
