class HomeController < ApplicationController
  before_action :check_admin_user, only: :admin
  
  def index
    @books = Book.where(hidden: false)
  end

  def admin

  end

  def profile
    @user = current_user
    @orders = @user.orders
  end

  def cart
    unless current_user
      redirect_to(root_path, alert: 'Чтобы посмотреть корзину - авторизуйтесь')
      return
    end

    @cart = current_user.orders.find_by(status: 'cart')

    unless @cart.present?
      redirect_to(root_path, alert: "Корзина пуста. Добавьте книги")
      return
    end
  
    @books = @cart.books
  end

  def update_user_role
    user = User.find(params[:user_id])
    user.update!(role: params[:role])

    redirect_to admin_path, notice: "Права у пользователя: #{user.email} были успешно изменены"
  end

  private

  def check_admin_user
    redirect_to(root_path) unless current_user && (current_user.worker? || current_user.admin?)
  end
end
