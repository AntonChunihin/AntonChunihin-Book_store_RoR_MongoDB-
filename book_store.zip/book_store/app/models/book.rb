class Book
  GENRES = [
    'роман',
    'философский роман',
    'фэнтези',
    'комедия',
    'боевик',
    'история',
    'приключения',
    'ужасы'
  ]

  include Mongoid::Document
  include Mongoid::Timestamps
  field :title, type: String
  field :author, type: String
  field :genre, type: Array
  field :age_rating, type: String
  field :language, type: String
  field :price, type: Integer
  field :cover_type, type: String
  field :number_of_pages, type: Integer
  field :weight, type: Integer
  field :publication_year, type: Integer
  field :isbn, type: Integer
  field :publisher, type: String
  field :description, type: String
  field :hidden, type: Boolean, default: false
  
  has_and_belongs_to_many :orders
end
