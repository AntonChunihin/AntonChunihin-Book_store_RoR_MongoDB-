class Order
  include Mongoid::Document
  include Mongoid::Timestamps
  field :number_of_positions, type: Integer
  field :delivery_address, type: String
  field :delivery_date, type: Date
  field :payment_kind, type: String
  field :total_cost, type: String
  field :status, type: String
  field :items_quantities, type: Hash
  
  belongs_to :user
  has_and_belongs_to_many :books, after_add: :update_totals

  def recalculate!
    total_cost = if items_quantities
                   sum = 0
                   books.each { |book| sum += book.price * items_quantities[book.id.to_s] }
                   sum
                 else
                   books.sum(:price)
                 end

    update!(total_cost: total_cost)
    update!(number_of_positions: books.count)
  end

  private

  def update_totals(_)
   recalculate!
  end
end
