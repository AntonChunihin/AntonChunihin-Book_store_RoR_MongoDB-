Rails.application.routes.draw do
  devise_for :users
  resources :books
  resources :orders

  root 'home#index'
  get '/admin', to: 'home#admin'
  get '/cart', to: 'home#cart'
  get '/profile', to: 'home#profile'
  patch '/update_user_role', to: 'home#update_user_role'

  get '/add_book_to_cart', to: 'orders#add_book_to_cart'
  patch '/checkout_cart', to: 'orders#checkout_cart'
  patch '/add_book_to_order', to: 'orders#add_book_to_order'
  patch '/remove_book_from_order', to: 'orders#remove_book_from_order'
  patch '/remove_book_from_cart', to: 'orders#remove_book_from_cart'
  patch '/update_item_quantity_in_cart', to: 'orders#update_item_quantity_in_cart'

  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
